<?php
include('header.php');
include("profileleft.php");

$usr_id='';
$action = '';

if(isset($_GET['action'])){
    $action = $_GET['action'];
}
	$usr_id = $_SESSION['usr_id'];  //customer_id

   	$listing_query = "SELECT * FROM `order_master` WHERE `customer_id` = '".$usr_id."' ";
	$listing_result = mysqli_query($conn, $listing_query);
 	
?>
<td width="80%">  
<table width="100%" border="1">
	<tr><th colspan="7"><h3>Your order...</h3></th></tr>
	<?php 
    if(isset( $_GET['id']) && $action == 'view'){

    	$id = $_GET['id'];
        $sql = "SELECT * FROM  `order_master`  WHERE `order_id`='".$id."' ";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result)
    ?>
    <tr align="center">
        <table border="1" width="100%" cellspacing="2">
        	<tr>
        		<th><b>First name</b></th>
        		<td><?php echo $row['first_name']; ?></td>
        	</tr>
        	<tr>
        		<th><b>Last name</b></th>
        		<td><?php echo $row['last_name']; ?></td>
        	</tr>
        	<tr>
				<th><b>Phone</b></th>
				<td><?php echo $row['phone']; ?></td>
			</tr>
			<tr>
				<th><b>Email</b></th>
				<td><?php echo $row['email']; ?></td>
			</tr>
			<tr>
				<th><b>Total product</b></th>
				<td><?php echo $row['total_product']; ?></td>
			</tr>
			<tr>
				<th><b>Total amount</b></th>
				<td><?php echo $row['total']; ?></td>
			</tr>
			<tr>
				<th><b>Shipping address</b></th>
				<td><textarea><?php echo $row['shipping_address']; ?></textarea></td>
        	</tr>
        	<tr>
				<th><b>Order status</b></th>
				<td><select name="order_status">
						<option value="#">--select--</option>

	                    <option value="0"<?php 
                            if($row['order_status'] == 0){ echo ' selected="selected"';} ?>>Progress</option>

	                    <option value="1"<?php 
                            if($row['order_status'] == 1){ echo ' selected="selected"';} ?>>Completed</option>

	                    <option value="3"<?php 
                            if($row['order_status'] == 3){ echo ' selected="selected"';} ?>>Cancle</option>
                    </select>
				</td>
        	</tr>
        	<tr>
    			<td colspan="2" align="center"><input type="submit" name="update" value="update"></td>
        	</tr>
        </table>      
    </tr>
    <?php }else{  ?>
	<form method="POST" action="order.php">
		<tr>
			<th><b>Date</b></th>
			<th><b>First name</b></th>
			<th><b>Last name</b></th>
			<th><b>Phone</b></th>
			<th><b>Total product</b></th>
			<th><b>Total amount</b></th>
			<th><b>Action</b></th>
		</tr> 
		<?php if($listing_result->num_rows > 0){
                  while ($row = mysqli_fetch_array($listing_result)){ ?>
		<tr align="center">
			<td><?php echo $row['date']; ?></td>
			<td><?php echo $row['first_name']; ?></td>
			<td><?php echo $row['last_name']; ?></td>
			<td><?php echo $row['phone']; ?></td>
			<td><?php echo $row['total_product']; ?></td>
			<td><?php echo $row['total']; ?></td>
			<td>
			   <a href="order.php?action=view&id=<?php echo $row['order_id']; ?>">view</a>
			</td>
		</tr>
		<?php }	} ?>
	</form>
	<?php } ?>
</table>
</td></tr>
</table>
</td></tr>
<?php include('footer.php'); ?>
