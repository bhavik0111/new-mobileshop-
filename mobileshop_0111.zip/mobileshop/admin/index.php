<?php 
   include('header.php');


?>
<tr><td width="100%">
	<table width="100%" border="0" >
		<tr><th colspan="2" align="center"><h2><?php if(isset($_SESSION["usr_role"]) && $_SESSION["usr_role"]==1){ echo "Welcome Admin" ;} ?></h2></th></tr>
	</table>
</td></tr>  
<?php include('footer.php'); ?>