<tr><td width="100%">
   <table width="100%" border="1">
   	<?php 
   	// if($submitedmsg != ''){ echo $submitedmsg; } ?>
   		<tr>
   			<td align="right" colspan="2">
   				<a href="<?php echo SITE_URL ?>"><b>Back</b></a>
   			</td>
   		</tr>
        <tr>
            <td width="20%">
           		<a href="<?php echo SITE_URL.'/editprofile.php';?>"><b>Edit</b></a>
				<br>
				<a href="<?php echo SITE_URL.'/order.php';?>"><b>Order</b></a>
         	</td>


		
	
