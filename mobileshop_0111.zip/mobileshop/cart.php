<?php
include("header.php");

$id='';
$prod_id='';
$prod_name='';
$prod_price='';
$prod_image='';
$cat_id="";
$imagepath='';
$cart_data='';
$total_product='';

if(isset($_GET['prod_id'])){
  $id = $_GET['prod_id'];
}

if(isset($_GET['cat']) && $_GET['cat']!=''){
  $cat_id=$_GET['cat'];	
}

if(isset($_GET['prod_qty']) && $_GET['prod_qty']!=''){
        $productqty=$_GET['prod_qty'];
}

	$prod_cookie = explode('#',$_COOKIE['cart_data_'.$_SESSION['usr_id']]); 
	      //Array ( [0] => 30$1 [1] => )

	$getprodid = array();
	$getprodqty = array();
	
		foreach($prod_cookie as $value){
				if($value){
					array_push($getprodid,explode('$',$value)[0]);
					array_push($getprodqty,explode('$',$value)[1]);
				}
		}
		// print_r($_COOKIE['cart_data_'.$_SESSION['usr_id']]);
	$prod_ids = implode(',', $getprodid);
	$prod_qtys = implode(',', $getprodqty);
		
?>
<tr><td>
<table border="0" width="100%" valign="top" align="center">
	<tr><th width="100%" align="center"><b><h2>Shopping Cart</h2></b></th></tr>
	<tr><td align="right">
   				<a href="<?php echo SITE_URL ?>"><b>Back</b></a>
   		</td></tr>	
	<tr>
		<table border="2" width="100%" cellspacing="0" align="center">
			
			<tr align="center">
					<td><b>Product</b></td>
					<td><b>Image</b></td>
					<td><b>Quantity</b></td>
					<td><b>Price</b></td>
					<td><b>Action</b></td>
			</tr>
				<?php  
          if($prod_ids !=''){             //<===if not product in cart===>

            	$prod_view_query = "SELECT * FROM `product_master` WHERE  `prod_id`  IN (".$prod_ids.") AND `prod_status`='1' ";
							$prod_view_result = mysqli_query($conn, $prod_view_query);
						 			// echo($prod_ids);

							$total = 0;
					    if($prod_view_result->num_rows > 0){  $counter = 0; 
									while($prod_row = $prod_view_result->fetch_assoc()){ 
									   	$qtypric = $prod_row["prod_price"] * $getprodqty[$counter];
									 		$total = $total+$qtypric; 
									 		
				?>
			<tr align="center" id="<?php echo $prod_row["prod_id"];?>" class="tr">
   
					<td><?php echo $prod_row["prod_name"];?></td>
				
					<td> 
		          <img src='<?php echo SITE_URL_IMG . '/product/' . $prod_row["prod_image"]; ?>' width="90" height="90">   
					</td>

					<td><input type="number" name="qty" value="<?php echo $getprodqty[$counter]; ?>"></td>

					<td><input type="text" name="price" value="<?php echo $qtypric;?>"></td>

					<td><input type="submit" name="editcart" value="Update" onclick="update(<?php echo $_SESSION['usr_id'];?>)"></td>
			</tr>
					<?php $counter++; } } ?>
			<tr>
					<td align="right" colspan="4"><b>Total: </b><input type="text" name="total" id="total" value="<?php echo $total;?>"></td>

					<td align="right"><a href="checkout.php"><b>Checkout</b></a></td>
			</tr>

		</table>
		<?php }else { ?>
		<tr><th colspan="5"><div style='color:red;'><h2><?php echo " Your Shoping Cart is empty. !!!"; } ?></h2></div></th></tr>
	</tr>
</table>
</td></tr>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="  crossorigin= "anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
<script>
	
	function update(usr_id){
					// $('#31')
			var cooki = '';
			$.removeCookie("cart_data_"+usr_id);

			$('.tr').each(function() {
				var qty = $(this).find('input[name=qty]').val();
				var prod_id = $(this).attr('id');    //get id of that element using attr

				if(qty > 0){   											 //<===if qty=0 remove product in cart===>
					cooki += prod_id+'$'+qty+'#';      // 32$1#
						
				  }
			});
			$.cookie("cart_data_"+usr_id, cooki,{
			  	path: "/"
			});
			location.reload();                     //<=====page refresh=====>
					 

			
	}
</script>
<?php include("footer.php"); ?>