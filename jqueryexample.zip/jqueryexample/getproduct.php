<?php
include 'connect.php';

if(isset($_POST['category']))
{
    $prod_name= '';

    $sql = "SELECT `prod_id`,`prod_name`,`prod_price` FROM `product_master` WHERE `cat_id` = ".$_POST['category']." AND`prod_status`='1' ";
    $result = mysqli_query($conn, $sql);
    $response = [];
    
    if ($result->num_rows > 0) 
    {
        while ($row = $result->fetch_assoc()) 
        {
            array_push($response, $row);
        }
        echo(json_encode($response));
        
    }
    
}
echo false;
?>
