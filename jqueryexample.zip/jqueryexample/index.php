<HTML>
<HEAD>
<title>
Jquery
</title>  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<style>
    .error{
        color:red;
    }
</style>
</HEAD>
<?PHP
include "connect.php";

//FOR SELECT DROPDOWN...
$cat_query = "SELECT `cat_id`,`cat_name` FROM `category_master`";
$cat_result = mysqli_query($conn, $cat_query);

 ?> 
<BODY>
<table align="center" border="1" cellspacing="0" cellpadding="15">
    <tr><td align="center" colspan="2"><b>jquery</b></td></tr>
        <form method="post" action="index.php" onsubmit="return checkvalide();">
            <tr><td>
                <input type="text" name="firstname" id="firstname" placeholder="First name" value=""><br>
                <div id="error_firstname" class="error" style="display: none;">Please add firstname</div>
            </td></tr>

            <tr><td>
                <input type="text" name="lastname" id="lastname" placeholder="Last name" value=""><br>
                <div id="error_lastname" class="error" style="display: none;">Please add lastname</div>
            </td></tr>

            <tr><td>
                <select name="cat_name" id="cat_name"><option value="">Select category</option>
                    <?php  if($cat_result->num_rows > 0){
                        while ($row = $cat_result->fetch_assoc()){ ?>

                        <option value="<?php echo $row['cat_id']; ?>" 
                            <?php if(isset($_GET['cat_name']) && $_GET['cat_name'] == $row['cat_id']){  echo 'selected'; } ?>><?php echo $row['cat_name']; ?>
                        </option>

                    <?php  } } ?>
                </select>
                <br>
                <div id="error_lastname" class="error" style="display: none;">Please select category</div>
            </td></tr>

            <tr><td>
                <select name="prod_id" id="prod_id"><option value="">Select Product</option>
                </select>
                <br>
                <div id="error_lastname" class="error" style="display: none;">Please select Product</div>
            </td></tr>

            <tr><td>
                <span>Price: $90</span>
                <span>Stock: 50</span>
                <input type="text" name="prod_qty" id="prod_qty" placeholder="Qty" value=""><br>
                <div id="error_lastname" class="error" style="display: none;">Please add Qty</div>
            </td></tr>

            <tr><td colspan="2" align="center">
                <input type="submit" name="bntsubmit">
            </td></tr>

        </form>
</table>
<script>
     function checkvalide(){

        $('.error').css("display","none");
        if($("#firstname").val() == ''){
            $("#error_firstname").css("display","block");
            // return false;
        }
        if($("#lastname").val() == ''){
            $("#error_lastname").css("display","block");
            return false;
        }
        return true;
        
    }



    // function checkvalide(){
    // 	alert($("#firstname").val());
    // 	if($("#firstname").val()!=''){
    // 		return true;
    // 	}else{
    // 		return false;
    // 	}
    // }


</script>

</BODY> 
</HTML>