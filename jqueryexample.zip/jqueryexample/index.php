<HTML>
<HEAD>
<title>
Jquery
</title>  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<style>
    .error{
        color:red;
    }
</style>
</HEAD>
<?PHP
include "connect.php";

//FOR SELECT DROPDOWN...
$cat_query = "SELECT `cat_id`,`cat_name` FROM `category_master`";
$cat_result = mysqli_query($conn, $cat_query);



if(isset($_POST['submit'])){
    $first_name = $_POST['firstname'];
    $last_name = $_POST['lastname'];
    $category = $_POST['cat_name'];
    $product = $_POST['prod_id'];
    $price = $_POST['prod_price'];
    $qty = $_POST['stockqty'];


    $query = "INSERT INTO `request_cotetion` (`firstname`,`lastname`,`cat_name`,`prod_id`,`prod_price`,`stockqty`) VALUES ('".$first_name."','".$last_name."','".$category."','".$product."','".$price."','".$qty."')";
    $result = mysqli_query($conn, $query);
}


?> 
<BODY>
<table width="20%" align="center" border="1" cellspacing="0" cellpadding="15">
    <tr><td align="center" width="80%" colspan="2"><b>jquery-ajax</b></td></tr>
        <form method="post" action="index.php" onsubmit="return checkvalide();">
            <tr><td>
                <input type="text" name="firstname" id="firstname" placeholder="First name" value=""><br>
                <div id="error_firstname" class="error" style="display: none;">PLEASE ADD FIRSTNAME</div>
            </td></tr>

            <tr><td>
                <input type="text" name="lastname" id="lastname" placeholder="Last name" value=""><br>
                <div id="error_lastname" class="error" style="display: none;">PLEASE ADD LASTNAME</div>
            </td></tr>

            <tr><td>
                <select name="cat_name" id="cat_name"><option value="">Select category</option>
                    <?php  if($cat_result->num_rows > 0){
                        while ($row = $cat_result->fetch_assoc()){ ?>
                            <option value="<?php echo $row['cat_id']; ?>" 
                                <?php if(isset($_GET['cat_name']) && $_GET['cat_name'] == $row['cat_id']){echo 'selected'; } ?>><?php echo $row['cat_name']; ?>
                            </option>
                    <?php  } } ?>
                </select><br>
                <div id="error_cat_name" class="error" style="display: none;">PLEASE SELECT CATEGORY</div>
            </td></tr>

            <tr><td>
                <select name="prod_id" id="prod_id"><option value="">Select product</option></select> <div id="error_prod_id" class="error" style="display: none;">PLEASE SELECT PRODUCT</div>
            </td></tr>

            <tr><td>
                <span name="prod_price" id="prod_price">Price: </span><br>
                <span name="stock" id="stock">Stock: </span><br>
                
                <!-- <span name="input" id="input">input: </span> -->

                <input type="text" name="stockqty" id="stockqty" placeholder="Qty" value=""><br>
                <div id="error_prod_qty" class="error" style="display: none;">PLEASE ENTER QTY</div>
                <div id="error_outqty" class="error" style="display: none;">Out of stock</div>
                <div id="error_doneqty" class="error" style="display: none;">Done</div>
            </td></tr>

            <tr><td colspan="2" align="center">
                <input type="submit" name="bntsubmit" id="submit">
            </td></tr>
        </form>
</table>
<script>
    function checkvalide(){

        $('.error').css("display","none");
        var returnform='true';

        if($("#firstname").val() == ''){
            $("#error_firstname").css("display","block");
            returnform='false';
        }
        if($("#lastname").val() == ''){
            $("#error_lastname").css("display","block");
            returnform='false';
        }
        if($("#cat_name").val() == ''){
            $("#error_cat_name").css("display","block");
            returnform='false';
        }
        if($("#prod_id").val() == ''){
            $("#error_prod_id").css("display","block");
            returnform='false';
        }
        if($("#stockqty").val() == ''){
            $("#error_prod_qty").css("display","block");
            returnform='false';
        }        

        // var qty   = $("#stockqty").val();

        if(returnform == 'true'){
            
            var firstname = $("#firstname").val();
            var lastname = $("#lastname").val();
            var catname = $("#cat_name").val();
            var prodid = $("#prod_id").val();
            var prodqty = $("#stockqty").val();
            
            $.ajax({
                url: '/test/bhavik/jqueryexample/getstockbyqty.php',
                type: 'POST',
                data: { prodid:prodid, prodqty:prodqty, catname:catname, lastname:lastname, firstname:firstname },
                dataType: 'json',
                success: function(response){

                    console.log(response);
                    // var stock = response;
                    // $("#stock").empty();

                    if(response==0){
                        $("#error_outqty").css("display","block");
                        returnform='false';
                        return false;
                    }else{
                         $("#error_doneqty").css("display","block");
                         returnform='false';
                    }
                }
            });
            return false;
        }
        else{
            return false;
        }
     
    }

// <==::::GET PRODUCT FROME CHOOSE CATEGORY::::==>

    $(document).ready(function(){
        $("#cat_name").change(function() {
            var catid = $(this).val();

            $.ajax({
                url: '/test/bhavik/jqueryexample/getproduct.php',
                type: 'POST',
                data: { category: catid },
                dataType: 'json',
                success: function(response){

                    var len = response.length;
                    console.log(response);
                    $("#prod_id").empty();
                    $("#prod_id").append("<option value=''>Select product</option>")

                    for(var i = 0; i < len; i++){
                        var id = response[i]['prod_id'];
                        var name = response[i]['prod_name'];

                        $("#prod_id").append("<option value='" + id + "'>" + name + "</option>");
                    }
                }
            });
        });
    });
//END

// <==::::GET PRICE FROME CHOOSE PRODUCT::::==>

    $(document).ready(function(){
        $("#prod_id").change(function(){
            var prodid = $(this).val();

            $.ajax({
                url: '/test/bhavik/jqueryexample/getprice.php',
                type: 'POST',
                data: { prod_id: prodid },
                dataType: 'json',
                success: function(response){

                    console.log(response);
                    $("#prod_price").empty();
                    var price = response[0]['prod_price'];

                    $('#prod_price').html('Price: $'+response);
                }
            });
        });
    });
//END


// <==:::: GET STOCK FROME CHOOSE PRODUCT ::::==>

    $(document).ready(function(){
        $("#prod_id").change(function(){
            var prodid = $(this).val();

            $.ajax({
                url: '/test/bhavik/jqueryexample/getstock.php',
                type: 'POST',
                data: { prod_id: prodid },
                dataType: 'json',
                success: function(response){

                    console.log(response);
                    $("#stock").empty();
                    var stock = response[0]['stock'];

                    $('#stock').html('Stock: '+response);
                }
            });
        });
    });
//END


// <==:::: GET QTY BY STOCK ::::==>
    
        // $("#prod_id").change(function(){
            
        // });
    
//END




    // function checkvalide(){
    //  alert($("#firstname").val());
    //  if($("#firstname").val()!=''){
    //      return true;
    //  }else{
    //      return false;
    //  }
    // }

</script>

</BODY> 
</HTML>