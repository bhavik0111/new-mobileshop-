<HTML>
<HEAD>
<title>
Jquery
</title>  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<style>
    .error{
        color:red;
    }
</style>
</HEAD>
<?PHP
include "connect.php";

//FOR SELECT DROPDOWN...
$cat_query = "SELECT `cat_id`,`cat_name` FROM `category_master`";
$cat_result = mysqli_query($conn, $cat_query);

 ?> 
<BODY>
<table align="center" border="1" cellspacing="0" cellpadding="15">
    <tr><td align="center" colspan="2"><b>jquery-ajax</b></td></tr>
        <form method="post" action="index.php" onsubmit="return checkvalide();">
            <tr><td>
                <input type="text" name="firstname" id="firstname" placeholder="First name" value=""><br>
                <div id="error_firstname" class="error" style="display: none;">PLEASE ADD FIRSTNAME</div>
            </td></tr>

            <tr><td>
                <input type="text" name="lastname" id="lastname" placeholder="Last name" value=""><br>
                <div id="error_lastname" class="error" style="display: none;">PLEASE ADD LASTNAME</div>
            </td></tr>

            <tr><td>
                <select name="cat_name" id="cat_name"><option value="">Select category</option>
                    <?php  if($cat_result->num_rows > 0){
                        while ($row = $cat_result->fetch_assoc()){ ?>
                            <option value="<?php echo $row['cat_id']; ?>" 
                                <?php if(isset($_GET['cat_name']) && $_GET['cat_name'] == $row['cat_id']){echo 'selected'; } ?>><?php echo $row['cat_name']; ?>
                            </option>
                    <?php  } } ?>
                </select><br>
                <div id="error_cat_name" class="error" style="display: none;">PLEASE SELECT CATEGORY</div>
            </td></tr>

            <tr><td>
                <select name="prod_id" id="prod_id"><option value="prod_id">Select product</option></select>
            </td></tr>

            <tr><td>
                <span>Price: $90</span><br>
                <span>Stock: 50</span>
                <input type="text" name="prod_qty" id="prod_qty" placeholder="Qty" value=""><br>
                <div id="error_prod_qty" class="error" style="display: none;">PLEASE ADD QTY</div>
            </td></tr>

            <tr><td colspan="2" align="center">
                <input type="submit" name="bntsubmit">
            </td></tr>

        </form>
</table>
<script>
    function checkvalide(){

        $('.error').css("display","none");

        if($("#firstname").val() == ''){
            $("#error_firstname").css("display","block");
            // return false;
        }
        if($("#lastname").val() == ''){
            $("#error_lastname").css("display","block");
            // return false;
        }
        if($("#cat_name").val() == ''){
            $("#error_cat_name").css("display","block");
            // return false;
        }
        if($("#prod_qty").val() == ''){
            $("#error_prod_qty").css("display","block");
            return false;
        }
        return true;
    }


   // GET Price frome Product_name....

        $(document).ready(function() {

            $("#cat_name").change(function() {
                var catid = $(this).val();

                $.ajax({
                    url: '/test/bhavik/jqueryexample/getproduct.php',
                    type: 'POST',
                    data: { category: catid },
                    dataType: 'json',
                    success: function(response){

                        var len = response.length;
                        console.log(response);
                        $("#prod_id").empty();

                        for (var i = 0; i < len; i++) {
                            var id = response[i]['prod_id'];
                            var name = response[i]['prod_name'];
                            var price = response[i]['prod_price'];

                            $("#prod_id").append("<option value='" + id + "'>" + name + "</option>");

                        }
                    }
                });
            });

        });



    



    // function checkvalide(){
    // 	alert($("#firstname").val());
    // 	if($("#firstname").val()!=''){
    // 		return true;
    // 	}else{
    // 		return false;
    // 	}
    // }


</script>

</BODY> 
</HTML>