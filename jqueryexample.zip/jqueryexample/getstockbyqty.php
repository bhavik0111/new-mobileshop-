<?php
include 'connect.php';

if(isset($_POST['prodid']))
{
    $sql = "SELECT `stock` FROM `product_master` WHERE `prod_id` = ".$_POST['prodid']." AND `prod_status`='1' ";
    $result = mysqli_query($conn, $sql);
    $response = '';
    
    if($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc()) 
        {
        
            if($row['stock'] < $_POST['prodqty']){
                $response = '0';
            }else{
                $response = '1';
            }
            echo(json_encode($response));
        }
    }
}

?>