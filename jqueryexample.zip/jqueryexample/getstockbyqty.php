<?php
include 'connect.php';

if(isset($_POST['prodid']))
{
    $sql = "SELECT `stock` FROM `product_master` WHERE `prod_id` = ".$_POST['prodid']." AND `prod_status`='1' ";
    $result = mysqli_query($conn, $sql);
    $response = 0;
    
    if($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc()) 
        {
        
            if($row['stock'] < $_POST['prodqty']){   //50<51==>"0" 
                $response = 0;
            }else{
                
                    $firstname = $_POST['firstname'];
                    $lastname = $_POST['lastname'];
                    $catname = $_POST['catname'];
                    $prodid = $_POST['prodid'];
                    $prodprice = $_POST['prodprice'];
                    $prodqty = $_POST['prodqty'];

                    $query = "INSERT INTO `request_cotetion` (`id`,`firstname`,`lastname`,`cat_id`,`prod_id`,`prod_price`,`stockqty`) VALUES (NULL,'".$firstname."','".$lastname."','".$catname."','".$prodid."','".$prodprice."','".$prodqty."')";
                    $insert_result = mysqli_query($conn, $query);
                    
                    $new_stock = $row['stock'] - $_POST['prodqty'];
                    $minus_query = "UPDATE `product_master` set stock = ".$new_stock. " where prod_id = ".$prodid;
                    $update_result = mysqli_query($conn, $minus_query);

                if($update_result){
                    $response = 1; 
                }
            }
        }
    }
    echo(json_encode($response));
}

?>
