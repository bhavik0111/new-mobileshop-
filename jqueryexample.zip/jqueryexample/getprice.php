<?php
include 'connect.php';

if(isset($_POST['prod_id']))
{
    $sql = "SELECT `prod_price` FROM `product_master` WHERE `prod_id` = ".$_POST['prod_id']." AND `prod_status`='1' ";
    $result = mysqli_query($conn, $sql);
    $response = '';
    
    if ($result->num_rows > 0) 
    {
        while ($row = $result->fetch_assoc()) 
        {
            // array_push($response, $row);
            $response = $row['prod_price'];
            echo(json_encode($response));
        }
    }
}

?>
