<?php
include 'header.php';

$id = '';
$usr_id = '';
$action = '';
$submitedmsg = '';
$order_id = '';
$query_search = '';
$query_string = '';
$order_ids = '';

 $query_search .= 'where 1 ';

//SEARCH....DROPDOWN....DATE
if(isset($_GET['search']) ||
   isset($_GET['usr_name']) ||              //customer dropdown
   isset($_GET['from_date']) ||
   isset($_GET['to_date']) ||
   isset($_GET['prod_name']) ||             //products dropdown
   isset($_GET['total_order']) )            //total order dropdown
{
    
   
    $query_string .= '';

    if(isset($_GET['search']) && $_GET['search'] != ''){
        $query_search .= " And (first_name LIKE '%" . $_GET['search'] . "%')";
        $query_string = $query_string . '&search='.$_GET['search'];
    }

    if(isset($_GET['from_date']) || isset($_GET['to_date'])){
        $to_date = $_GET['to_date'];

            if($_GET['to_date'] == ''){
                $to_date = date('Y-m-d');
            }

            if(isset($_GET['from_date']) && $_GET['from_date'] != ''){
                $from_date = $_GET['from_date'];
                $query_string = $query_string . '&from_date='.$_GET['from_date'];
                $query_search .= " And order_date >= '" . $from_date .  "'";
            }

        $query_search .= " AND order_date <= '" . $to_date . "' ";
        $query_string = $query_string . '&to_date='.$_GET['to_date'];
    }

    if(isset($_GET['usr_name']) && $_GET['usr_name'] != ''){
        $query_search = $query_search . " And customer_id = '".$_GET['usr_name']."'";
        $query_string = $query_string . '&usr_name='.$_GET['usr_name'];
    }

    if(isset($_GET['prod_name']) && $_GET['prod_name'] != ''){

        $prod_query_search = "SELECT `order_id`  FROM `order_products` where product_id = '".$_GET['prod_name']."' GROUP BY `order_id`";
        $prod_query_result = mysqli_query($conn, $prod_query_search);
        $fetch = mysqli_fetch_all($prod_query_result, MYSQLI_ASSOC);
        $order_ids = array_column($fetch,'order_id');
        $order_ids = implode(',',$order_ids);

        $query_search = $query_search . " And order_id In (".$order_ids.")";
        $query_string = $query_string . '&prod_name='.$_GET['prod_name'];
    }

    if(isset($_GET['total_order']) && $_GET['total_order'] != ''){

        $query_search = $query_search . " And `order_date` >= DATE_SUB(now(), INTERVAL ".$_GET['total_order'].") ";
        $query_string = $query_string . '&total_order='.$_GET['total_order'];
    }
    // echo($query_search); 
    // exit;
}

//END....

//FOR SELECT DROPDOWN...
$user_query = "SELECT `usr_id`,`usr_name` FROM `user_master`";
$user_result = mysqli_query($conn, $user_query);

$prod_query = "SELECT `prod_id`,`prod_name` FROM `product_master`  ";
$prod_result = mysqli_query($conn, $prod_query);
//END....


$listing_query_for_count = "SELECT * FROM `order_master` $query_search ";
$listing_result_for_count = mysqli_query($conn, $listing_query_for_count);
$total_records = $listing_result_for_count ? $listing_result_for_count->num_rows : 0;

$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;


$listing_query = "SELECT * FROM `order_master` LEFT JOIN `user_master` ON order_master.customer_id=user_master.usr_id $query_search LIMIT  $offset, $total_records_per_page";
$listing_result = mysqli_query($conn, $listing_query);

?>
<tr><td width="80%">
    <table width="100%" border="1">
       
        <tr><th colspan="10"><h2>REPORTS</h2></th></tr>

        <tr><td align="right" colspan="10">
           
            Total order amount : <?php echo amount($conn,'1',$query_search); ?><br>
            Total remainig amount : <?php echo amount($conn,'2',$query_search); ?><br>
            Total cancel amount : <?php echo amount($conn,'3',$query_search); ?> 
        </td></tr>
        
        <tr><td colspan="11">
        <form method="get" action="report.php">
            <input type="text" placeholder="Search.." name="search" value="<?php if(isset($_GET['search'])){ echo $_GET['search'];} ?>">

            <b>Date: </b><input type="date" name="from_date" value="<?php if(isset($_GET['from_date'])){ echo $_GET['from_date']; } ?>">
        
            <b>To: </b><input type="date" name="to_date" value="<?php if(isset($_GET['to_date'])){ echo $_GET['to_date']; } ?>">&nbsp;&nbsp;&nbsp;

            <b>Customer</b>
                <select name="usr_name"><option value="">---select---</option><?php
                    if($user_result->num_rows > 0){
                        while ($row = $user_result->fetch_assoc()){ ?>

                        <option value="<?php echo $row['usr_id']; ?>"
                            <?php if(isset($_GET['usr_name']) && $_GET['usr_name'] == $row['usr_id']){  echo 'selected'; } ?>><?php echo $row['usr_name']; ?>
                        </option>

                    <?php } } ?>
                </select>&nbsp;&nbsp;&nbsp;

            <b>Products</b>
                <select name="prod_name"><option value="">---select---</option><?php 
                    if($prod_result->num_rows > 0){
                        while ($row = $prod_result->fetch_assoc()){ ?>

                        <option value="<?php echo $row['prod_id']; ?>" 
                            <?php if(isset($_GET['prod_name']) && $_GET['prod_name'] == $row['prod_id']){  echo 'selected'; } ?>><?php echo $row['prod_name']; ?>
                        </option>

                    <?php  } } ?>
                </select>&nbsp;&nbsp;&nbsp;

            <!--  // $all = "SELECT * FROM `order_master` WHERE `order_date` >= DATE_SUB(now(), INTERVAL 6 MONTH)";  
                   // $res = mysqli_query($conn,$all); -->

            <b>Total Order</b>
                <select name="total_order">
                    <option value="">All</option> 

                    <option value="1 YEAR" <?php if(isset($_GET['total_order']) && $_GET['total_order']=="1 YEAR"){ echo 'selected'; } ?>>Last year</option>

                    <option value="6 MONTH" <?php if(isset($_GET['total_order'])&& $_GET['total_order']=="6 MONTH"){ echo 'selected'; } ?>>Last 6 months</option>
                </select>
            <button type="submit" id="search_btn" class="btn btn-outline-warning">Search</button>
        </form>
        </td></tr>    
        <tr>
            <th>Order ID</th>
            <th>Customer ID</th>
            <th>First name</th>
            <th>Last name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Total product</th>
            <th>Total amount</th>
            <th>Order status</th>
            <th>Order date</th>
        </tr> 
        <?php 
        if($listing_result && $listing_result->num_rows > 0){
            while($row = mysqli_fetch_array($listing_result)){ 
        ?>
        <tr align="center">
            <td><?php echo $row['order_id']; ?></td>
            <td><?php echo $row['customer_id'] . '#' .$row['usr_name']; ?></td>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['phone']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['total_product']; ?></td>
            <td><?php echo $row['total']; ?></td>  <!-- total amount -->
            <td><?php
                    if($row['order_status'] == 1){ echo 'completed'; }
                    if($row['order_status'] == 2){ echo 'progress'; }
                    if($row['order_status'] == 3){ echo 'cancel'; }
                ?>
            </td>
            <td><?php echo $row['order_date']; ?></td>
        </tr>
            <?php } } ?>
        <tr><td colspan="11"><?php include 'pagination.php'; ?></td></tr>
    </table>
</td></tr>
<?php include 'footer.php'; ?>