<?php
include 'header.php';

$id = '';
$usr_id = '';
$action = '';
$submitedmsg = '';
$order_id = '';
$query_search = '';
$query_string = '';


if(isset($_GET['id'])){
    $id = $_GET['id'];
}

if(isset($_GET['action'])){
    $action = $_GET['action'];
}

// MSG DISPLAY.........
if(isset($_GET['msg']) && $_GET['msg'] == 'U'){ 
    $submitedmsg = 'Address Updated'; 
}

if(isset($_GET['msg']) && $_GET['msg'] == 'C'){     //<==1==>
    $submitedmsg = 'Order completed'; 
}

if(isset($_GET['msg']) && $_GET['msg'] == 'P'){     //<==2==>
    $submitedmsg = 'Now Order in progress'; 
} 

if(isset($_GET['msg']) && $_GET['msg'] == 'D'){     //<==3==>
    $submitedmsg = 'Order Cancelled SuccessFully'; 
} 

if(isset($_GET['msg']) && $_GET['msg'] == 'DD'){     
    $submitedmsg = 'Order Deleted SuccessFully'; 
}
//END MSG


//SEARCH....DROPDOWN....DATE
if(isset($_GET['search']) ||
   isset($_GET['usr_name']) ||
   isset($_GET['from_date']) ||
   isset($_GET['to_date'])){
    
    $query_search .= 'where 1 ';

    $query_string .= '';

    if(isset($_GET['search']) && $_GET['search'] != ''){
        $query_search .= " And (first_name LIKE '%" . $_GET['search'] . "%')";
        $query_string = $query_string . '&search='.$_GET['search'];
    }

    if(isset($_GET['usr_name']) && $_GET['usr_name'] != ''){
        $query_search = $query_search . " And customer_id = '" . $_GET['usr_name'] . "'";
        $query_string = $query_string . '&usr_name='.$_GET['usr_name'];
    }
    
    
    if(isset($_GET['from_date']) || isset($_GET['to_date'])){
        $to_date = $_GET['to_date'];

        if($_GET['to_date'] == ''){
            $to_date = date('Y-m-d');
        }

        if(isset($_GET['from_date']) && $_GET['from_date'] != ''){
            $from_date = $_GET['from_date'];
            $query_string = $query_string . '&from_date='.$_GET['from_date'];
            $query_search .= " And order_date >= '" . $from_date .  "'";
        }

        $query_search .= " AND order_date <= '" . $to_date . "' ";
        $query_string = $query_string . '&to_date='.$_GET['to_date'];
    }
}
// echo $query_string;
//END....

//FOR SELECT DROPDOWN...
$user_query = "SELECT `usr_id`,`usr_name` FROM `user_master`";
$user_result = mysqli_query($conn, $user_query);
//END....

if(isset($_POST['submit'])){
    $shipping_address = $_POST['shipping_address'];

    $user_update ="UPDATE `order_master` SET `shipping_address`='".$shipping_address."' WHERE `order_id`='".$id."' ";

    $user_result = mysqli_query($conn, $user_update);
    header('location:order.php?msg=U');
}

//UPDATE ....

if(isset($_GET['id']) && $action == 'complete'){
    $id = $_GET['id'];

    $order_status = 1;

    $complete_order ="UPDATE `order_master` SET `order_status` ='".$order_status."' WHERE  `order_id`='".$id."' ";
    $update_query = mysqli_query($conn, $complete_order);
    if($update_query){
        header('location:order.php?msg=C');
    }
}

if(isset($_GET['id']) && $action == 'progress'){
    $id = $_GET['id'];

    $order_status = 2;

    $progress_order ="UPDATE `order_master` SET `order_status` ='".$order_status."' WHERE `order_id`='".$id."' ";

    $update_query = mysqli_query($conn, $progress_order);
    if($update_query){
        header('location:order.php?msg=P');
    }
}

if(isset($_GET['id']) && $action == 'cancel'){
    $id = $_GET['id'];

    $order_status = 3;

    $cancle_order ="UPDATE `order_master` SET `order_status` ='".$order_status."' WHERE `order_id`='".$id."' ";
    $update_query = mysqli_query($conn, $cancle_order);
    if($update_query){
        header('location:order.php?msg=D');
    }
}
            
if (isset($_GET['id']) && $action == 'delete'){
    $id = $_GET['id'];

    $order_deletemstr = mysqli_query($conn, "DELETE  FROM  `order_master` WHERE `order_id`='".$id."' ");
    $result_deleteprdct = mysqli_query($conn, "DELETE  FROM  `order_products` WHERE `order_id`='".$id."' ");

   if($order_deletemstr && $result_deleteprdct){
        header("location:order.php?msg=DD");
    }
}

//END UPDATE............

//Listing data

$listing_query_for_count = "SELECT * FROM `order_master` $query_search";
$listing_result_for_count = mysqli_query($conn, $listing_query_for_count);
$total_records = $listing_result_for_count->num_rows;
// echo $total_records;

$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;
// echo $total_no_of_pages;
// exit;


$listing_query = "SELECT * FROM `order_master` LEFT JOIN `user_master` ON order_master.customer_id=user_master.usr_id  $query_search LIMIT  $offset, $total_records_per_page";
$listing_result = mysqli_query($conn, $listing_query);

?>
<tr><td width="80%">
    <table width="100%" border="1">
        <?php if ($submitedmsg != '') {   echo $submitedmsg; } ?>
        <tr><th colspan="11"><h2>All orders...</h2></th></tr>
        
        <?php 
        if(isset($_GET['id']) && $action == 'view'){

            $id = $_GET['id'];
            $sql = "SELECT * FROM  `order_master`  WHERE `order_id`='".$id."' ";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_array($result);
        ?>
        <tr align="center">         <!--SHIPPING ADDRESS UPDATE PERPOSE(action=id)-->
            <form method="POST" action="order.php?id=<?php echo $row['order_id']; ?>"> 
            <table border="1" width="100%" cellspacing="2">
                <tr>
                    <td align="right" colspan="2">
                        <a href="<?php echo SITE_URL .'/admin/order.php'; ?>"><b>Back</b></a>
                    </td>
                </tr>
                <tr>
                    <th>First name</th>
                    <td><?php echo $row['first_name']; ?></td>
                </tr>
                <tr>
                    <th>Last name</th>
                    <td><?php echo $row['last_name']; ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo $row['phone']; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $row['email']; ?></td>
                </tr>
                <tr>
                    <th>Products</th>
                    <td><?php
                    $sql ="SELECT `product_name`,`prod_image`,`product_qty`,`product_price` FROM `order_products` LEFT JOIN `product_master` ON order_products.product_id = product_master.prod_id WHERE `order_id`='" .$id."' ";

                    $prod_result = mysqli_query($conn, $sql); ?>

                    <table border="1" width="100%" cellspacing="2">
                        <tr>
                            <th>Product</th>
                            <th>Image</th>
                            <th>Qty</th>
                            <th>Price</th>
                        </tr>
                        <?php while($prod = mysqli_fetch_array($prod_result)) { ?>

                        <tr align="center">
                            <td><?php echo $prod['product_name']; ?></td>

                            <td><?php if($prod['prod_image']==''){ ''; }else{ ?><img src='<?php echo SITE_URL_IMG .'/product/'.$prod['prod_image']; ?>' width="90" height="90"><?php } ?></td>

                            <td><?php echo $prod['product_qty']; ?></td>

                            <td><?php echo $prod['product_price']; ?></td>
                        </tr>
                        <?php } ?>
                        <tr>
                            <td align="right" colspan="2"><b>Total product: </b></td>
                            <td align="center"><b><?php echo $row['total_product']; ?></b></td>
                        </tr>
                    </table>
                    </td>
                </tr>
                <tr>
                    <th>Total amount</th>
                    <td><?php echo $row['total']; ?></td>
                </tr>
                <tr>
                    <th>Shipping address</th>
                    <td><textarea name="shipping_address"><?php echo $row['shipping_address']; ?></textarea></td>
                </tr>
                <tr>
                    <th>Order status</th>
                    <td><?php 

                    if($row['order_status'] != 3){

                        if($row['order_status'] == 1){ echo '<b>Your order Completed..</b>'; ?> <br>

                            <a href="order.php?action=progress&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure ... you want to order in progress??');"><b>Order Progress</b></a><?php
                        }
                        if($row['order_status'] == 2){ echo '<b>Your order in Progress.....</b>'; ?> <br>
                            <a href="order.php?action=complete&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure ... you want to order completed??');"><b>Order Complete</b></a><?php
                        }?>
                        <h3>
                            <a href="order.php?action=cancel&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure... you want to cancel order??');"><b>Cancel order</b></a>&nbsp;&nbsp;

                            <a href="order.php?action=delete&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure... you want to Delete order??');"><b>Delete order</b></a>
                        </h3><?php

                    }else{ ?>

                        <h2><b><?php if($row['order_status'] == 3){ ?><div style='color:red;'><?php echo '<b>Your order Cancelled..!!</b>'; ?></div><?php } ?>
                        
                            <a href="order.php?action=progress&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure ... you want to order in progress??');"><b>Order Progress</b></a>&nbsp;&nbsp;
                            
                            <a href="order.php?action=complete&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure ... you want to order completed??');"><b>Order Complete</b></a>&nbsp;&nbsp;

                            <a href="order.php?action=delete&id=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure... you want to Delete order??');"><b>Delete order</b></a>

                        </b></h2>
                    <?php } ?>
                    </td>
                </tr>
                <tr>   
                   <td colspan="2" align="center"><input type="submit" name="submit" value="submit"></td>  
                </tr>
            </table>
            </form>       
        </tr>
        <?php } else { ?>  <!--listing-->

        <tr><td colspan="11">
        
            <form method="get" action="order.php"> 
                <input type="text" placeholder="Search.." name="search" value="<?php if(isset($_GET['search'])){ echo $_GET['search'];} ?>">

                <select name="usr_name"><option value="">---select---</option><?php 

                    if($user_result->num_rows > 0){
                        while ($row = $user_result->fetch_assoc()){ ?>

                        <option value="<?php echo $row['usr_id']; ?>" 
                            <?php if(isset($_GET['usr_name']) && $_GET['usr_name'] == $row['usr_id']){  echo 'selected'; } ?>><?php echo $row['usr_name']; ?>
                        </option>

                    <?php } } ?>
                </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                <b>Date: </b><input type="date" name="from_date" value="<?php if( isset($_GET['from_date'])){ echo $_GET['from_date']; } ?>">
            
                <b>To: </b><input type="date" name="to_date" value="<?php if( isset($_GET['to_date'])){ echo $_GET['to_date']; } ?>">

                <button type="submit" id="search_btn" class="btn btn-outline-warning">Search</button>
            </form>
               
        </td></tr>    
        <tr>
            <th>Order ID</th>
            <th>Customer ID</th>
            <th>First name</th>
            <th>Last name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Total product</th>
            <th>Total amount</th>
            <th>Order status</th>
            <th>Order date</th>
            <th>Action</th>
        </tr> 
        <?php 
        if($listing_result->num_rows > 0){
            while($row = mysqli_fetch_array($listing_result)){ 
        ?>
        <tr align="center">
            <td><?php echo $row['order_id']; ?></td>
            <td><?php echo $row['customer_id'] . '#' .$row['usr_name']; ?></td>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['phone']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['total_product']; ?></td>
            <td><?php echo $row['total']; ?></td>  <!-- total amount -->
            <td><?php
                    if($row['order_status'] == 1){ echo 'completed'; }
                    if($row['order_status'] == 2){ echo 'progress'; }
                    if($row['order_status'] == 3){ echo 'cancel'; }
                   
                ?>
            </td>
            <td><?php echo $row['order_date']; ?></td>
            <td>
                <a href="order.php?action=view&id=<?php echo $row['order_id']; ?>">view</a>
            </td>
        </tr>
            <?php } } ?>
        <tr><td colspan="11"><?php include 'pagination.php'; ?></td></tr>
        <?php } ?>
    </table>
</td></tr>
<?php include 'footer.php'; ?>