<?php

    $page_no = 0;
    $total_no_of_pages = 0;

    if(isset($_GET['page_no']) && $_GET['page_no'] != ''){
        $page_no = $_GET['page_no'];
      }else{
        $page_no = 1;
    }
    $total_records_per_page = 10;
    $offset = ($page_no - 1) * $total_records_per_page;
    $previous_page = $page_no - 1;
    $next_page = $page_no + 1;
    $adjacents = '2';

function check_login_status(){        // check user login or not.........

    if(isset($_SESSION['usr_id'])){
      return $_SESSION['usr_id'];
    }
    return false;
}

// function amount($conn,$order_status='1'|| $order_status='2' || $order_status='3'){

    function amount($conn,$order_status,$query_search){
        
        $complt = mysqli_query($conn,"SELECT SUM(`total`) as compltamout FROM `order_master` $query_search and `order_status`='".$order_status."' "); 
        $complt_res = mysqli_fetch_array($complt);

    // if($complt_res =='' ){echo '0';}else{
    return $complt_res['compltamout'];   
     // }
}

?>