<?php
   include('header.php');

?>
<tr>
	<td align="right" colspan="2">
		<a href="<?php echo SITE_URL ; ?>"><b>Back</b></a>
	</td>
</tr>	
<tr><td width="100%">
		<?php include('profileleft.php'); ?>
		   
			<td width="80" align="center">
				<?php 
					if(isset($_SESSION["usr_role"]) && $_SESSION["usr_role"]==1){ echo "<h2>Welcome Admin</h2>" ;}else{echo "<h2>Welcome user</h2>";}?>
			</td>
		</tr></table>

</td></tr>
<?php include('footer.php'); ?>
