<?php
 include('header.php');
include("profileleft.php");

 if(isset($_GET["msg"]) && $_GET["msg"] == 'U'){
 	$submitedmsg = 'Record Updated';
 }

if(isset($_SESSION['usr_name']) && isset($_SESSION['usr_id']))
{ 
	$usr_name='';
	$usr_email='';
	$usr_password='';
	$usr_id ='';
	$submitedmsg='';

		 $update_query = "SELECT * FROM `user_master` WHERE `usr_id` =  '".$_SESSION['usr_id']."' ";
		 $update_result = mysqli_query($conn, $update_query);
		 $user_row  = $update_result->fetch_assoc();

		 $usr_name  = $user_row['usr_name'];
		 $usr_email = $user_row['usr_email'];
		 $usr_password = $user_row['usr_password'];
		

	  if(isset($_POST['submit']) && $_POST['submit']=='Edit'){
	
		 $usr_name  = $_POST['usr_name'];
		 $usr_email = $_POST['usr_email'];
		 $usr_password = $_POST['usr_password'];

			if($usr_email!=''){
					$query = "SELECT * FROM `user_master` WHERE `usr_email`='".$usr_email."' AND `usr_id` !='".$_SESSION['usr_id']."' "; 
				
					$result = mysqli_query($conn, $query);
					$total  = mysqli_num_rows($result);
						if($total>0){
								$emailexist="Email is already Exists";
						}	
				}
		   
					if($_POST['submit']=='Edit')
					{
						$user_update = "UPDATE `user_master` SET `usr_name`='".$usr_name."',`usr_email`='".$usr_email."' WHERE `usr_id`='".$_SESSION['usr_id']."' ";
						$user_result = mysqli_query($conn, $user_update);
      
								if($usr_password !='')
								{
									$user_update = "UPDATE `user_master` SET `usr_password`='".md5($usr_password)."' WHERE `usr_id`='".$_SESSION['usr_id']."' ";
									$user_result = mysqli_query($conn, $user_update);
								}
								header("location:profile.php?msg=U");
					}
		}
}
?>       
      	<td width="80%">  
          <table width="100%" border="1">
            <form method="POST" action="editprofile.php">
										<?php if($submitedmsg != ''){ echo $submitedmsg; } ?>
								<tr>
									<th>Name</th>
									<td><input type="text" name="usr_name" value="<?php echo $usr_name; ?>"></td>
								</tr>
								<tr>
									<th>Email</th>
									<td><input type="email" name="usr_email" value="<?php echo $usr_email; ?>"></td>
								</tr>
								<tr>
									<th>Password</th>
									<td><input type="password" name="usr_password"></td>
								</tr>
								<tr>
									<td colspan="2" align="center"><input type="submit" name="submit" value="Edit"></td>
								</tr>
						</form>
          </table>
        </td>
      </tr>
   </table>
</td></tr>
<?php include('footer.php'); ?>
