<!-- addtocart.php -->

<?php
include('admin/connect.php');
session_start();

$submitedmsg = '';

if(isset($_GET["msg"]) && $_GET["msg"] == 'U'){
	$submitedmsg = 'Please login ';
	
}

if(isset($_GET['prod_id']) && $_GET['prod_id']!=''){
	$prodid=$_GET['prodid'];	
}

if(isset($_SESSION['usr_name']) && isset($_SESSION['usr_id']))
{
         ?><h1 align="center">Welcome</h1><?php



}
else{
    header("Location:".SITE_URL."/index.php?msg");
 }

?>
	

