<?php
include('admin/connect.php');
session_start();

$prodid="";
$productqty = 1;

	//if login then after view this addproduct.........
if(isset($_GET['prod_id']) && $_GET['prod_id']!=''){
	$prodid=$_GET['prod_id'];	
}
if(isset($_GET['prod_qty']) && $_GET['prod_qty']!=''){
    $productqty=$_GET['prod_qty'];
}

if(isset($_SESSION['usr_name']) && isset($_SESSION['usr_id']))
{
	//set the cookies......
    if($prodid!='' && !isset($_COOKIE['prod_id_'.$_SESSION['usr_id']])){
        
      setcookie('prod_id_'.$_SESSION['usr_id'], $prodid."$".$productqty."#", time() + 48 * 3600, '/');

        setcookie("user[user_id]",$_SESSION['usr_id']);
        setcookie("user[prod_id]",$prodid);
        setcookie("user[prod_qty]",$productqty);
	}

    if(isset($_COOKIE['user'])){

        foreach($_COOKIE['user'] as $name => $value){
            $name = htmlspecialchars($name);
            $value = htmlspecialchars($value);

            // echo "$name : $value <br>\n";

            header("Location:".SITE_URL."/index.php?msg=A");
        }
    }
}
else{
    header("Location:".SITE_URL."/index.php?msg=L");  //please login
 }

?>