<?php
include("header.php");

$id='';
$prod_id='';
$prod_name='';
$prod_price='';
$prod_image='';
$cat_id="";
$imagepath='';

if(isset($_GET['prod_id'])){
  $id = $_GET['prod_id'];
}

if(isset($_GET['cat']) && $_GET['cat']!=''){
	$cat_id=$_GET['cat'];	
}

$prod_view_query = "SELECT * FROM `product_master` WHERE `prod_id`='".$id."' AND `prod_status`='1' ";
$prod_view_result = mysqli_query($conn, $prod_view_query);
$prod_row  = mysqli_num_rows($prod_view_result);


?>

<tr><td>
<table border="0" width="100%" valign="top" align="center">
	<tr><th width="100%" align="center"><b><h2>Cart</h2></b></th></tr>	
	<tr>
	<table border="1" width="100%" valign="top" align="center">
		<tr>
			<td><b>product</b></td>
			<td><b>image</b></td>
			<td><b>price</b></td>
			<td><b>Quantity</b></td>
			<td><b>Action</b></td>
		</tr>
			<?php 
				// if($prod_row->num_rows > 0){
				// 	while($show_prod = mysqli_fetch_array($prod_row)){ 
			?>
		<tr>
			<td>asda</td>
			<td><?php
				
				if($prod_row["prod_image"]!=''){
					$imagepath= $_SERVER['DOCUMENT_ROOT'].'/test/bhavik/mobileshop/images/'.$prod_row["prod_image"];

					if(file_exists($imagepath)){
						$image=SITE_URL_IMG.'prodimg/'.$prod_row["prod_image"];
						echo ' <img src="'.$image.'" width="100" height="100">';
					}
				}
			?>
			</td>
			<td></td>
			<td><input type="number" name="qty"></td>
			<td><input type="submit" name="editcart" value="Update"></td>
		</tr>
			<?php
			 // }} ?>
		<tr><td colspan="5" align="right"><a href="#"><b>Checkout</b></a></td></tr>
	</table>
	</tr>
</table>
</td></tr>
<?php include("footer.php"); ?>

<!-- // echo "'.$imagepath.'" ;?> height="100" width="100" > -->