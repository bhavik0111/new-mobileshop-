<?php
include("header.php");

$id='';
$prod_id='';
$prod_name='';
$prod_price='';
$prod_image='';
$cat_id="";
$imagepath='';

if(isset($_GET['prod_id'])){
  $id = $_GET['prod_id'];
}

if(isset($_GET['cat']) && $_GET['cat']!=''){
  $cat_id=$_GET['cat'];	
}

if(isset($_GET['prod_qty']) && $_GET['prod_qty']!=''){
        $productqty=$_GET['prod_qty'];
}
	$prod_cookie = explode('#',$_COOKIE['cart_data_'.$_SESSION['usr_id']]);

	$getprodid = array();
	$getprodqty = array();
	
		foreach($prod_cookie as $value){
			if($value){
				array_push($getprodid,explode('$',$value)[0]);
				array_push($getprodqty,explode('$',$value)[1]);
			}
		}
	$prod_ids = implode(',',$getprodid);
	// echo($prod_ids);

	$prod_view_query = "SELECT * FROM `product_master` WHERE  `prod_id`  IN (".$prod_ids.") AND `prod_status`='1' ";
	$prod_view_result = mysqli_query($conn, $prod_view_query);
	
?>
<tr><td>
<table border="0" width="100%" valign="top" align="center">
	<tr><th width="100%" align="center"><b><h2>Shopping Cart</h2></b></th></tr>
	<tr><td align="right">
   			<a href="<?php echo SITE_URL ?>"><b>Back</b></a>
   	</td></tr>	
	<tr>
	<table border="2" width="100%" cellspacing="0" align="center">
		<tr align="center">
			<td><b>Product</b></td>
			<td><b>Image</b></td>
			<td><b>Quantity</b></td>
			<td><b>Price</b></td>
			<td><b>Action</b></td>
		</tr>
		    <?php  if($prod_view_result->num_rows > 0){
					  while($prod_row = $prod_view_result->fetch_assoc()){ 
                        $qty = 0 ;
					  	?>

		<tr align="center">
			<td><?php echo $prod_row["prod_name"];?></td>

			<td> 
                <img src='<?php echo SITE_URL_IMG . '/product/' . $prod_row["prod_image"]; ?>' width="90" height="90">   
			</td>

			<td><input type="number" name="qty" value="<?php echo $getprodqty[$qty]; ?>"></td>

			<td><?php echo $prod_row["prod_price"];?></td>

			<td><input type="submit" name="editcart" value="Update"></td>
		</tr>
			<?php $qty++; } } ?>
		<tr>
			<td align="right" colspan="4"><b>Total: </b><input type="text" name="total" id="total" onclick="calculate(row)"></td>
			<td align="right"><a href="#"><b>Checkout</b></a></td>
		</tr>
	</table>
	</tr>
</table>
</td></tr>
<?php include("footer.php"); ?>
