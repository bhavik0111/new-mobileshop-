<?php

$page_no = 0;
$total_no_of_pages = 0;

if(isset($_GET['page_no']) && $_GET['page_no'] != ''){
    $page_no = $_GET['page_no'];
  }else{
    $page_no = 1;
}
$total_records_per_page = 7;
$offset = ($page_no - 1) * $total_records_per_page;
$previous_page = $page_no - 1;
$next_page = $page_no + 1;
$adjacents = '2';

function check_login_status(){        //check user login or not.........

    if(isset($_SESSION['usr_id'])){
      return $_SESSION['usr_id'];
    }
    return false;
}

// function amount($conn,$order_status,$query_search){

//     $complt = mysqli_query($conn,"SELECT SUM(`total`) as compltamout FROM `order_master` ".$query_search." AND `order_status`=".$order_status); 
//     $complt_res = mysqli_fetch_array($complt);

//    return  $complt_res['compltamout'] ? $complt_res['compltamout'] : 0; 
// }





function amount($conn, $order_status, $query_search)
{

   if(isset($_GET['prod_name']) && $_GET['prod_name'] != ''){

        $total_query = "SELECT SUM(`order_products`.`product_price` * `order_products`.`product_qty`) as total_price FROM `order_products` LEFT JOIN `order_master` ON `order_master`.`order_id`=`order_products`.`order_id` " . $query_search . " AND `order_status`=" . $order_status. " and order_products.product_id = " . $_GET['prod_name'];
   }else{

        $total_query = "SELECT SUM(`order_products`.`product_price`) as total_price FROM `order_master`LEFT JOIN `order_products` ON `order_master`.`order_id`=`order_products`.`order_id` " . $query_search . " AND `order_status`=" . $order_status;
   }

    $complt = mysqli_query($conn,$total_query);
    $complt_res = mysqli_fetch_array($complt);

    return $complt_res['total_price'] ? $complt_res['total_price'] : 0;
}



// SELECT SUM(`order_products`.`product_price`) as totalprice FROM `order_master` 
// LEFT JOIN `order_products` ON `order_master`.`order_id`=`order_products`.`order_id` 
// WHERE `order_products`.`product_id`=33 and `order_master`.order_status=1;

?>
