<?php 
include('login_header.php');

$submitedmsg = '';
$usr_email = '';
$usr_password = '';

if(isset($_POST['submit']))
{
    $usr_email =$_POST['usr_email'];
    $usr_password =$_POST['usr_password'];

    $u_block = "SELECT * FROM `user_master` WHERE `usr_email`='".$usr_email."' AND `usr_password`='".md5($usr_password)."' AND `status`='1' AND `usr_block`='unblock' ";
    $u_block_res = mysqli_query($conn, $u_block);
    $u_block_num = mysqli_num_rows($u_block_res);  


    if($u_block_num > 0){
            
        $usr_query = "SELECT * FROM `user_master` WHERE `usr_email`='".$usr_email."' AND `usr_password`='".md5($usr_password)."' AND `status`='1' ";
        $usr_result = mysqli_query($conn, $usr_query); 

        if(mysqli_num_rows($usr_result) == 1)
        {
            $usr_row = $usr_result->fetch_assoc(); 

            $_SESSION["usr_id"]   = $usr_row['usr_id'];
            $_SESSION["usr_email"] = $usr_row['usr_email'];          
            $_SESSION["usr_role"] = $usr_row['usr_role'];
            
                if(isset($_SESSION["usr_role"]))
                {
                    if($_SESSION["usr_role"] == 1){
                        header("Location:".SITE_URL."/admin");
                    }
                    else{ header("Location:".SITE_URL."/index.php");}
                }
        }
        else{
            header("location:".SITE_URL."/login.php?msg=E");
        }

    }else{
          header("location:".SITE_URL."/login.php?msg=A");
    }
    
}


if(isset($_GET["msg"]) && $_GET["msg"] == 'E'){
    $submitedmsg = "Please Enter Valid email and password!";
}
if(isset($_GET["msg"]) && $_GET["msg"] == 'A'){
    $submitedmsg = '<h3>You are not login please contect admin</h3>';
}
?>
<tr><td align="center"><h3><b>User login</b></h3></td></tr>
<tr><td align="center">
    <?php if($submitedmsg != ''){ echo $submitedmsg; } ?>
</td></tr>
<tr><td>
    <form method="post" action="login.php">    
        <table align="center" border="1" cellspacing="0" cellpadding="15">
            <tr>
                <th colspan="2" align="center">Login hear...</th>
            </tr>
            <tr>
                <th>Email</th>
                <td><input type="text" name="usr_email" placeholder="enter email..."> 
            </tr>
            <tr>
                <th>Password</th>
                <td><input type="password" name="usr_password" placeholder="enter password..."></td>
            </tr>
            <tr>
                <td colspan="2" align="center"><input type="submit" name="submit" value="Login"></td>
            </tr>
        </table>
    </form>
</td></tr>
<?php include('login_footer.php');    ?>