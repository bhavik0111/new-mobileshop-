<?php
   include('header.php');

?>
<tr><td width="100%">
		<?php include('profileleft.php'); ?>
		
			<td width="80" align="center">
				<?php if(isset($_SESSION["usr_role"])){ echo "Welcome ". $_SESSION["usr_role"];}?>
			</td>
		</tr></table>

</td></tr>
<?php include('footer.php'); ?>
