<?php
include("header.php");
if(check_login_status() == false){     //<=====if login then-after view this checkout page=====>
	header("location:index.php");
}
   	
$first_name='';
$last_name='';
$phone='';
$email='';
$shipping_address='';
$customer_id='';

    if(isset($_POST['submit'])){
	   	$first_name = $_POST['first_name'];
	   	$last_name  = $_POST['last_name'];
	   	$phone      = $_POST['phone'];
	   	$email      = $_POST['email'];
	   	$shipping_address = $_POST['shipping_address'];

        $ordrmstr = "INSERT INTO `order_master` (`first_name`,`last_name`,`phone`,`email`,`shipping_address`) VALUES ('".$first_name."','".$last_name."','".$phone."','".$email."','".$shipping_address."')";
       	
        $result = mysqli_query($conn,$ordrmstr);

        $last_id = $conn->insert_id;

        // foreach ($_POST['product_name'] as $key => $value) 
        // {
         
        $ordrprdt = mysqli_query($conn, "INSERT INTO `order_products` (`ordprod_id`, `order_id`, `customer_id`, `product_id`, `product_name`, `product_qty`, `product_price`) VALUES ('', '" . $last_id . "', '" . $_POST['customer_id'] . "', '" . $_POST['product_id'] . "','" . $_POST['product_name'] . "', '" . $_POST['product_qty']. "', '" . $_POST['product_price'] . "')");
        // }


		if($result){
	        echo "<h3> Data inserted  </h3>";
	        header("refresh:2");
	    }
        	
	}	
?>
<tr><td>
	<table border="0" width="100%" valign="top" align="center">
		<tr><th width="100%" align="center"><b><h2>Checkout</h2></b></th></tr>
		<tr><td align="right">
	   			<a href="<?php echo SITE_URL ?>"><b>Back</b></a>
	   		</td>
	   	</tr>	
		<tr>
			<form action="checkout.php" method="POST">
			<table border="1" width="100%" cellspacing="0" align="center" cellpadding="15">
				
				<tr>
					<th><b>First Name</b></th>
					<td><input type="text" name="first_name"></td>
				</tr>
				<tr>
					<th><b>Last Name</b></th>
					<td><input type="text" name="last_name"></td>
				</tr>
				<tr>
					<th><b>Phone</b></th>
					<td><input type="number" name="phone"></td>
				</tr>
				<tr>
					<th><b>Email</b></th>
					<td><input type="email" name="email"></td>
				</tr>
				<tr>
					<th><b>Shipping Address</b></th>
					<td><textarea name="shipping_address"></textarea></td>
				</tr>
				
				<tr>
					<th><b>Products list</b></th>
					<td></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
			</form>
		</tr>
	</table>
</td></tr>

<?php include("footer.php"); ?>
