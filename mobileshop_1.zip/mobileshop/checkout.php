<?php
include("header.php");
if(check_login_status() == false){     //<=====if login then-after view this checkout page=====>
	header("location:index.php");
}
   	
$first_name='';
$last_name='';
$phone='';
$email='';
$shipping_address='';
$customer_id='';
$total='';
// $usr_id = '';

if(isset($_GET['prod_id'])){
  $id = $_GET['prod_id'];
}

if(isset($_GET['cat']) && $_GET['cat']!=''){
  $cat_id=$_GET['cat'];	
}

// if(isset($_GET['prod_qty']) && $_GET['prod_qty']!=''){
//         $productqty=$_GET['prod_qty'];
// }

//<===  for product listed
	$prod_cookie = explode('#',$_COOKIE['cart_data_'.$_SESSION['usr_id']]); 
     
	    $getprodid = array();
		$getprodqty = array();

		foreach($prod_cookie as $value){
			if($value){
				array_push($getprodid,explode('$',$value)[0]);
				array_push($getprodqty,explode('$',$value)[1]);
			}
		}
	$prod_ids = implode(',', $getprodid);
	$prod_qtys = implode(',', $getprodqty); 

	$prod_list_query = "SELECT * FROM `product_master` WHERE  `prod_id`  IN (".$prod_ids.") AND `prod_status`='1' ";
	$prod_list_result = mysqli_query($conn, $prod_list_query);       // =======>


if(isset($_POST['submit'])){
	$usr_id     = $_SESSION['usr_id'];  //customer_id
   	$first_name = $_POST['first_name'];
   	$last_name  = $_POST['last_name'];
   	$phone      = $_POST['phone'];
   	$email      = $_POST['email'];
   	$total_product = $_POST['total_product'];
    $total      = $_POST['total'];
   	$shipping_address = $_POST['shipping_address'];
   

    $ordrmstr = "INSERT INTO `order_master` (`customer_id`,`first_name`,`last_name`,`phone`,`email`,`total_product`,`total`,`shipping_address`) VALUES ('".$usr_id."','".$first_name."','".$last_name."','".$phone."','".$email."','".$total_product."','".$total."','".$shipping_address."')";
    $result = mysqli_query($conn,$ordrmstr);
	$last_id = $conn->insert_id;
	$prod_cookie = explode('#',$_COOKIE['cart_data_'.$_SESSION['usr_id']]);

	    foreach($prod_cookie as $value){
			if($value){
				array_push($getprodid,explode('$',$value)[0]);
				array_push($getprodqty,explode('$',$value)[1]);
	        }
	    }
        $prod_ids = implode(',', $getprodid);


		$fetch="SELECT * FROM `product_master` where prod_id IN (".$prod_ids.") ";
		$proresult= mysqli_query($conn,$fetch);
		$prorecord = mysqli_num_rows($proresult);

		if($prorecord>0){ $counter = 0;
			while($row = $proresult->fetch_assoc()){ 
			
			$query="INSERT INTO `order_products`(`ordprod_id`, `order_id`,`customer_id`, `product_id`, `product_name`, `product_qty`,`product_price`) VALUES ('','".$last_id."','".$usr_id."','".$row["prod_id"]."','".$row["prod_name"]."','".$getprodqty[$counter]."','".$row["prod_price"]."')";
			$record=mysqli_query($conn,$query);
			$counter++ ;
		}  }
	
 		if($result){
	        echo "<h3> Data inserted  </h3>";
	        header("refresh:2");
		}	
}	
?>
<tr><td>
	<table border="0" width="100%" valign="top" align="center">
		<tr><th width="100%" align="center"><b><h2>Checkout</h2></b></th></tr>
		<tr><td align="right">
	   			<a href="<?php echo SITE_URL ?>"><b>Back</b></a>
	   		</td>
	   	</tr>	
		<tr>
		<form action="checkout.php" method="POST">
		<table border="1" width="100%" cellspacing="0" align="center" cellpadding="15">
			
			<tr>
				<th><b>First Name</b></th>
				<td><input type="text" name="first_name"></td>
			</tr>
			<tr>
				<th><b>Last Name</b></th>
				<td><input type="text" name="last_name"></td>
			</tr>
			<tr>
				<th><b>Phone</b></th>
				<td><input type="number" name="phone"></td>
			</tr>
			<tr>
				<th><b>Email</b></th>
				<td><input type="email" name="email"></td>
				
			</tr>
			<tr>
				<th><b>Shipping Address</b></th>
				<td><textarea name="shipping_address"></textarea></td>
			</tr>
		<!-- 	<tr>
				<th><b>Status</b></th>
				<td><input type="radio" name="status" value="0">0 &nbsp;&nbsp;
                	<input type="radio" name="status" value="1">1 &nbsp;&nbsp;
                	<input type="radio" name="status" value="3">3
                </td>
			</tr> -->
			<tr>
				<th><b>Products list :-</b></th>
				<td><?php 
			    	if($prod_list_result->num_rows > 0){ $counter = 0; $total = 0; $total_product = 0;
						while($prod_row = $prod_list_result->fetch_assoc()){ 
                            $qtypric = $getprodqty[$counter]*$prod_row["prod_price"];
							$total += $qtypric;  
							$total_product +=  $getprodqty[$counter]; ?><br>

					<?php echo $prod_row["prod_name"] ."*". $getprodqty[$counter]; ?>

					<input type="hidden" name="prod_id[]" value="<?php echo $prod_row["prod_id"];?>">
					<input type="hidden" name="qty[]" value="<?php echo $getprodqty[$counter];?>">
                    <input type="hidden" name="price[]" value="<?php echo $qtypric;?>">

					<?php   $counter++ ; } } ?>
					<input type="hidden" name="total" value="<?php echo $total;?>"> 
					<input type="hidden" name="total_product" value="<?php echo $total_product;?>">
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="submit" value="submit"></td>
			</tr>
		</table>
		</form>
		</tr>
	</table>
</td></tr>

<?php include("footer.php"); ?>
