<?php
include('header.php');
include("profileleft.php");

?>
<td width="80%">  
<table width="100%" border="1">
	<tr><th colspan="2"><h3>Update Order</h3></th></tr>
	<form method="POST" action="order.php">
		<tr>
			<th><b>First Name</b></th>
			<td><input type="text" name="first_name"></td>
		</tr>
		<tr>
			<th><b>Last Name</b></th>
			<td><input type="text" name="last_name"></td>
		</tr>
		<tr>
			<th><b>Phone</b></th>
			<td><input type="number" name="phone"></td>
		</tr>
		<tr>
			<th><b>Shipping Address</b></th>
			<td><textarea name="shipping_address"></textarea></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="submit" value="Edit"></td>
		</tr>
	</form>
</table>
</td></tr>
</table>
</td></tr>
<?php include('footer.php'); ?>
