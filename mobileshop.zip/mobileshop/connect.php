<?php
$dbhost ="localhost";
$dbusername ="root";
$dbpassword ="";
$dbname ="comp_mobile_shop";

 $conn = mysqli_connect($dbhost, $dbusername, $dbpassword, $dbname);

  if(!$conn){
    echo "database could not connect" .mysqli_error($conn);
  }

define("SITE_URL", "http://localhost/bhavik/mobileshop");
define("SITE_ROOT_URL", $_SERVER['DOCUMENT_ROOT']."/bhavik/mobileshop"); 
define("SITE_ROOT_IMG", $_SERVER['DOCUMENT_ROOT']."/bhavik/mobileshop/images"); 
define("SITE_URL_IMG", "http://localhost/bhavik/mobileshop/images");  //listing image path
  
?>
