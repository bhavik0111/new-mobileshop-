
	<table border="1" width="20">
		<tr>
			<td width="20">   
				<a href="<?php echo SITE_URL.'/editprofile.php';?>"><b>Edit</b></a>
				<br>
				<a href="#"><b>Order</b></a>
			</td>

		
	
