<?php
include('header.php');
include("left_panel.php");

$prod_id='';
$prod_name='';
$prod_price='';
$prod_image='';
$sort_order ='';
$order ='';
$shorting_query='';

   //ascending descending.....
   if(isset($_GET['s'])){
      $sort_order = strtolower($_GET['s']);

         if($sort_order ==  'n_asc'){
            $order = 'asc';
            $shorting_query = 'ORDER BY `prod_name`' . $order;
         }elseif($sort_order ==  'n_desc'){
            $order = 'desc';
            $shorting_query = 'ORDER BY `prod_name`' . $order;
         }elseif($sort_order ==  'pl'){
            $order = 'asc';
            $shorting_query = 'ORDER BY `prod_price`' . $order;
         }elseif($sort_order ==  'ph'){
            $order = 'desc';
            $shorting_query = 'ORDER BY `prod_price`' . $order;
         }
         else{
            $order = 'asc';
            $shorting_query = 'ORDER BY `prod_name`' . $order;
         }
   }
   
      $prod_sql = "SELECT `prod_id`, `prod_name`, `prod_price`, `prod_image` FROM `product_master` WHERE `prod_status`='1' $cat_name_query  $shorting_query  " ;      
    
      $prod_result = mysqli_query($conn, $prod_sql);  
 
?>
         <td width="80%">
            <table width="100%" border="1">
               <tr><td colspan="3" align="right">
                  <form action="index.php" method="GET">
                     <?php if($cat_id){ ?>
                        <input type="hidden" name="cat_id" value="<?php echo $cat_id; ?>">
                        <?php } ?>
                        <select name="s">
                              <option value="0">--Select--</option>
                              <option value="n_asc"<?php if($sort_order=='n_asc'){ echo ' selected="selected"';}?>>Asc</option>
                              <option value="n_desc"<?php if($sort_order=='n_desc'){ echo ' selected="selected"';}?>>Dsc</option>
                              <option value="pl"<?php if($sort_order=='pl'){ echo ' selected="selected"';}?>>Price Low-to-High</option>
                              <option value="ph"<?php if($sort_order=='ph'){ echo ' selected="selected"';}?>>Price High-to-Low</option>

                        </select>
                        <!-- <input type="submit" name="search" value="<?php if (isset($_GET['search'])) {echo $_GET['search']; } ?>"><button type="submit" value="Search">Search</button> -->
                     <input type="submit" value="Search">
                  </form>
               </td></tr>
               <tr>
                 <?php if($prod_result->num_rows > 0){
                        while($prod_row = $prod_result->fetch_assoc()){  
                          if($count %3==0 && $count != 0){ echo "  <tr> </tr>"; }  
                     ?>
                  <td align="center"><b>
                     <a href="<?php echo SITE_URL ?>/productview.php?<?php  
                                 if($cat_id > 0){ 
                                    echo 'cat_id='.$cat_id ; 
                                 }?>&prod_id=<?php echo $prod_row['prod_id']; ?>">

                        <img src="<?php echo SITE_URL_IMG . '/product/' . $prod_row['prod_image']; ?>" height="130" width="130" >
                     </a>
                        <br><?php echo $prod_row['prod_name']; ?>
                        <br>Price:  <?php echo $prod_row['prod_price']; ?><br>
                     <a href="#">Add To Cart</a></b>
                  </td>
                  <?php
                     $count++;
                    } } ?>
               </tr>
            </table>
         </td>
      </tr>
   </table>
</td></tr>
<?php include('footer.php'); ?>