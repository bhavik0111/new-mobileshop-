<?php
   include('login_header.php');
?>
<tr><td width="100%">
	<table align="center" border="1" cellspacing="1" width="100%">
		<tr><td colspan="2" align="right">
			<a href="<?php echo SITE_URL.'/profile.php';?>"><b>Back</b></a>
		</td></tr>
		
		<tr>
			<td width="20%">
				JN CJNC
			</td>
			
		</tr>
	</table>
</td></tr>
<?php include('login_footer.php'); ?>