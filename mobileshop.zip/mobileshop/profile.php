<?php
   include('login_header.php');
?>

<tr><td width="100%">
	<table width="100%" >
		
		<tr>
			<td width="20%">
				<li><a href="<?php echo SITE_URL.'/editprofile.php';?>"><b>Edit</b></a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<li><a href="#"><b>Order</b></a></li>
			</td>
			<td width="80">
				<table border="1">
					<tr><td>
						<?php if(isset($_SESSION["usr_role"])){ echo "Welcome ". $_SESSION["usr_role"];}?>
					</td></tr>
				</table>
			</td>
		</tr>
	</table>
</td></tr>
<?php include('login_footer.php'); ?>
